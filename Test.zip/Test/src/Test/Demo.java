package Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;

public class Demo {


	static AppiumDriver driver;
	static DesiredCapabilities capabilities = new DesiredCapabilities();

	@BeforeClass()
	public static void init() throws MalformedURLException {
		capabilities.setCapability("automationName", "XCUITest");
		capabilities.setCapability("deviceName", "iPad Air 2");
		capabilities.setCapability("udid", "e73fb47d6af24628c2b60e8727ee6dcc6cb1107f");
		capabilities.setCapability("platformName", "iOS");
		capabilities.setCapability("platformVersion", "12.4");
		capabilities.setCapability("xcodeOrgId", "P258R4GL6F");
		capabilities.setCapability("xcodeSigningId", "iPhone Developer"); 
		capabilities.setCapability("bundleId", "com.lbg.safari.launcher");
		capabilities.setCapability("browser", "safari");
		capabilities.setCapability("useNewWDA", true);
		driver = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),
				capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void googleTest() {
		driver.get("http://www.google.com");
	}

}
