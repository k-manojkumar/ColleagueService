package Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class TestAuto {


	static ExtentTest test;
	static ExtentReports report;


	//@Test
	public void testPhone() throws MalformedURLException {

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("automationName", "XCUITest");
		caps.setCapability("deviceName", "iPad Air 2");
		caps.setCapability("udid", "e73fb47d6af24628c2b60e8727ee6dcc6cb1107f");
		caps.setCapability("platformName", "iOS");
		caps.setCapability("platformVersion", "12.4");
		caps.setCapability("bundleId", "org.tcs.lbgdemo1");
		//caps.setCapability("app", "/Users/cbsadmin/Desktop/SampleApp.ipa");
		//caps.setCapability(MobileCapabilityType.APP, "/Users/cbsadmin/Desktop/Customer-BOS.app");
		caps.setCapability("autoAcceptAlerts", "true");

		AppiumDriver<MobileElement> appium = new IOSDriver<MobileElement>(new URL("http://localhost:4723/wd/hub"),caps);
		appium.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		appium.launchApp();

		MobileElement userName =  appium.findElementByAccessibilityId("UserName");
		userName.click();
		userName.sendKeys("ASD");
		MobileElement pwd =  appium.findElementByAccessibilityId("pwd");
		pwd.click();
		pwd.sendKeys("123");
		MobileElement button =  appium.findElementByName("Submit");

		button.click();

		//MobileElement results =  appium.findElementByAccessibilityId("Result");
		MobileElement results =  appium.findElementByAccessibilityId("Login Success");
		//appium.findElementByAccessibilityId("User Name").sendKeys("ASD");



		if(results.getText().equals("Login Success"))
		{
			System.out.println("Result value is " +results.getText());
		}
		else
		{
			System.out.println("Result value is ---> Login Failed");
		}

	}

	 @Test
	public void customerApp() throws InterruptedException, IOException {

		initateReport();


		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("automationName", "XCUITest");
		caps.setCapability("deviceName", "iPad Air 2");
		caps.setCapability("platformName", "iOS");
		caps.setCapability("platformVersion", "12.4");
		caps.setCapability(MobileCapabilityType.APP, "/Users/cbsadmin/Desktop/Customer.app");
		//caps.setCapability(CapabilityType.BROWSER_NAME, "safari");
		test = report.createTest("Customer App Test");

		ExtentTest testNode = test.createNode("Application Launch");

		AppiumDriver<MobileElement> appium = new IOSDriver<MobileElement>(new URL("http://localhost:4723/wd/hub"),caps);
		appium.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		testNode.info("Launching the Customer App");

		MobileElement contButton = appium.findElementByName("Continue");
		contButton.click();
		String screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Launched the Customer App", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Club Lloyds Screen Validation");
		MobileElement personalButton = appium.findElementByName("Personal");
		personalButton.click();
		testNode.info("Personal Banking Screen Loaded");

		MobileElement productsButton = appium.findElementByName("Our products");
		productsButton.click();
		testNode.info("Our Products Screen Loaded");

		MobileElement clubButton = appium.findElementByName("Club Lloyds");
		clubButton.click();
		Thread.sleep(3500);
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Club Lloyds Screen Loaded", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Classic Account Screen Validation");
		MobileElement closeButton = appium.findElementByName("Close");
		closeButton.click();
		testNode.info("Our Products Screen Loaded");

		MobileElement classicButton = appium.findElementByName("Classic Account");
		classicButton.click();
		Thread.sleep(3000);
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Classic Account Screen Loaded", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Overdraft calculator Screen Validation");
		closeButton = appium.findElementByName("Close");
		closeButton.click();
		testNode.info("Our Products Screen Loaded");

		MobileElement odCalcButton = appium.findElementByName("Overdraft calculator");
		odCalcButton.click();
		Thread.sleep(3000);
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Overdraft calculator Screen Loaded", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Cash ISA Screen Validation");
		closeButton = appium.findElementByName("Close");
		closeButton.click();
		testNode.info("Our Products Screen Loaded");

		MobileElement isaButton = appium.findElementByName("Cash ISAs");
		isaButton.click();
		Thread.sleep(3000);
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Cash ISAs Screen Loaded", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Mortgage Calculator Screen Validation");
		closeButton = appium.findElementByName("Close");
		closeButton.click();
		testNode.info("Our Products Screen Loaded");

		MobileElement mortCalcButton = appium.findElementByName("Mortgage calculator");
		mortCalcButton.click();
		Thread.sleep(3000);
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Mortgage calculator Screen Loaded", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Credit Cards Screen Validation");
		closeButton = appium.findElementByName("Close");
		closeButton.click();
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Our Products Screen Loaded", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		MobileElement ccButton = appium.findElementByName("Credit cards with rewards");
		ccButton.click();
		Thread.sleep(3500);
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Credit cards with rewards Screen Loaded", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Ways to Access Screen Validation");
		closeButton = appium.findElementByName("Close");
		closeButton.click();
		testNode.info("Our Products Screen Loaded");

		MobileElement backButton = appium.findElementByName("Back");
		backButton.click();
		testNode.info("Personal Banking Screen Loaded");

		MobileElement digiServicesButton = appium.findElementByName("Our digital services");
		digiServicesButton.click();
		testNode.info("Our digital services Screen Loaded");

		MobileElement mobBankingButton = appium.findElementByName("Mobile Banking");
		mobBankingButton.click();
		testNode.info("Mobile Banking Screen Loaded");

		MobileElement intBankingButton = appium.findElementByName("Internet Banking");
		intBankingButton.click();
		testNode.info("Internet Banking details Loaded");

		MobileElement mobBankingButton1 = appium.findElementByName("Mobile Banking");
		mobBankingButton1.click();
		testNode.info("Mobile Banking details Loaded");

		MobileElement tabBankingButton = appium.findElementByName("Tablet Banking");
		tabBankingButton.click();
		testNode.info("Tablet Banking details Loaded");
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Ways to Access Screens Validated", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Benifits Screen Validation");
		backButton = appium.findElementByName("Back");
		backButton.click();
		testNode.info("Our digital services Screen Loaded");

		MobileElement offersButton = appium.findElementByName("Everyday Offers");
		offersButton.click();
		testNode.info("Everyday Offers details Loaded");

		MobileElement edBankingButton = appium.findElementByName("Everyday Banking");
		edBankingButton.click();
		testNode.info("Everyday Banking details Loaded");

		MobileElement dsButton = appium.findElementByName("Digital Services");
		dsButton.click();
		testNode.info("Digital Services details Loaded");

		MobileElement paymentsButton = appium.findElementByName("Payments");
		paymentsButton.click();
		testNode.info("Payments details Loaded");

		MobileElement hsButton = appium.findElementByName("Help & Support");
		hsButton.click();
		testNode.info("Help & Support details Loaded");
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Benifit Screens Validated", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		testNode = test.createNode("Application Closure");

		backButton = appium.findElementByName("Back");
		backButton.click();
		testNode.info("Our digital services Screen Loaded");

		backButton.click();
		testNode.info("Personal Banking Screen Loaded");

		backButton.click();
		testNode.info("Home Screen Loaded");

		Thread.sleep(500);

		appium.closeApp();
		screenshoot = ((TakesScreenshot)appium).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Application Closed Successfully", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());

		finishReport();

		appium.quit();



	}



	public void initateReport() {

		Date date = Calendar.getInstance().getTime();
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMM_HHmm");
		SimpleDateFormat dateFormatForReport = new SimpleDateFormat("dd MMM yyyy");
		String fileName = System.getProperty("user.dir") +"/test-reports/CustomerAppTestReport"+ dateFormat.format(date) +".html";

		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
		report = new ExtentReports(); 
		htmlReporter.config().setAutoCreateRelativePathMedia(true);
		htmlReporter.config().setCSS("css-string");
		htmlReporter.config().setDocumentTitle("Customer App Test Report");
		htmlReporter.config().setEncoding("utf-8");
		htmlReporter.config().setJS("js-string");
		htmlReporter.config().setProtocol(Protocol.HTTPS);
		htmlReporter.config().setReportName("Customer App Test Report");
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
		report.attachReporter(htmlReporter);
		report.setSystemInfo("Application Name", "Customer App");
		report.setSystemInfo("Simulator", "iPad Air (3rd generation)");
		report.setSystemInfo("Report Date", dateFormatForReport.format(date));
		//return fileName;

	}



	public void finishReport() {
		report.flush();

	}

}
