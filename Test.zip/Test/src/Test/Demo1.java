package Test;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;


public class Demo1 {
	

	static AppiumDriver driver;
	static DesiredCapabilities capabilities = new DesiredCapabilities();
	
	/**
	 * Varibales for Extend Report
	 */
	static ExtentTest test;
	static ExtentReports report;

	@BeforeClass()
	public static void init() throws IOException {
		//DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.2");
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Safari");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPad Air (3rd generation");
		capabilities.setCapability("startIWDP", true);
		capabilities.setCapability(MobileCapabilityType.UDID, "auto");
		//capabilities.setCapability(MobileCapabilityType.UDID, "e73fb47d6af24628c2b60e8727ee6dcc6cb1107f");
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
		//capabilities.setCapability("app", "/Users/cbsadmin/Desktop/SampleApp.app");
		//capabilities.setCapability("xcodeSigningId", "iPhone Developer"); 
		
		driver = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),
				capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
		initateReport("BOS_TestReport_");
		
		test = report.createTest("Bank Of Scotland");
		ExtentTest testNode = test.createNode("Application Launch");
		testNode.info("Launching the BOS Site");
		driver.get("https://www.bankofscotland.co.uk/");
		String screenshoot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Launched the  BOS site", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());
		
		
	}

	@Test
	public void findUs() throws IOException, InterruptedException {
		
		ExtentTest testNode = test.createNode("Finding Nearest BOS Branch");
		testNode.info("Navigation to Find Us Screen");
		driver.findElement(By.xpath("//*[@id=\"nav-header\"]/div/div/ul/li[1]/a/span")).click();
		Thread.sleep(2000);
		String screenshoot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Navigated to the Find Us Screen", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());
		
		testNode.info("Searching for the nearest Branch");
		driver.findElement(By.id("branch-finder-input")).sendKeys("Trinity Road, Halifax");
		Thread.sleep(3000);
		driver.findElement(By.name("search")).click();
		
		
		//String ResultsRecords = driver.findElement(By.xpath("//*[@id=\"main\"]/div[3]/div/div/div/div/div/div/div[2]/div/div/p")).getText();
		//System.out.println("No. Of Search result records " + ResultsRecords);
		
		String nearestBranch = driver.findElement(By.xpath("//*[@id=\"main\"]/div[3]/div/div/div/div/div/div/div[4]/div/div/ul/li[1]/div/a")).getText();
		String screenshoot1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Branch search results.  Nearest Branch - " + nearestBranch, MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot1).build());
		Thread.sleep(3000);
		
		//Click on Home
		driver.findElement(By.xpath("/html/body/div[1]/header/div[2]/div[1]/div/div[3]/div/div/ul/li[1]/a")).click();;
		Thread.sleep(2000);
	}

	@Test
	public void register() throws IOException, InterruptedException {
		
		ExtentTest testNode = test.createNode("Registering for the Online Banking");
		testNode.info("Navigation to Registration Screen");
		driver.findElement(By.xpath("//span[contains(text(), 'Register')]")).click();
		String screenshoot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Navigated to the Registration Screen", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot).build());
		Thread.sleep(3000);
		
		testNode.info("Entering Customer Name");
		driver.findElement(By.id("frm_personalRegistration:txttitle")).sendKeys("Mr");
		driver.findElement(By.id("frm_personalRegistration:txtFirstName")).sendKeys("Test");
		driver.findElement(By.id("frm_personalRegistration:txtsurname")).sendKeys("Testone");
		
		testNode.info("Date Of Birth Selection");
		Select day = new Select(driver.findElement(By.id("frm_personalRegistration:slctDateDay")));
		day.selectByValue("16");
		
		Select month = new Select(driver.findElement(By.id("frm_personalRegistration:slctDateDay.month")));
		month.selectByIndex(01);
		
		Select year = new Select(driver.findElement(By.id("frm_personalRegistration:slctDateDay.year")));
		year.selectByIndex(20);
		
		testNode.info("Enter Postcode");
		driver.findElement(By.id("frm_personalRegistration:txtPostcode")).sendKeys("M22 9AN");

		testNode.info("Enter Sort Code");
		driver.findElement(By.id("frm_personalRegistration:strSortCode")).sendKeys("12");
		driver.findElement(By.id("frm_personalRegistration:strSortCode_p2")).sendKeys("11");
		driver.findElement(By.id("frm_personalRegistration:strSortCode_p3")).sendKeys("03");
		
		testNode.info("Enter Account Number");
		driver.findElement(By.id("frm_personalRegistration:strAccountNumber")).sendKeys("10336669");
		
		String screenshoot1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Filled all the details", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot1).build());
		Thread.sleep(5000);
		
		driver.findElement(By.id("frm_personalRegistration:continuebutton1")).click();
		String screenshoot2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
		testNode.pass("Clicked on Continue", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot2).build());
		
		String Errormsg = driver.findElement(By.className("formSubmitError")).getText();
		String strExp = "9200165 : Unfortunately there has been a technical problem. This transaction has not been completed.";
		Thread.sleep(3000);
		
		if (Errormsg.trim().equals(strExp)) {
			String screenshoot3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
			testNode.pass("Validation of Error message. Actual Error - " + Errormsg, MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot3).build());
		}
		else {
			String screenshoot3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
			testNode.fail("Validation of Error message. Actual Error - " + Errormsg + "Expected Error " + strExp, MediaEntityBuilder.createScreenCaptureFromBase64String(screenshoot3).build());
		}
			
	}
	
	
	public static void initateReport(String reportName) {

		Date date = Calendar.getInstance().getTime();
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMM_HHmm");
		SimpleDateFormat dateFormatForReport = new SimpleDateFormat("dd MMM yyyy");
		String fileName = System.getProperty("user.dir") +"/test-reports/"+ reportName + dateFormat.format(date) +".html";

		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
		report = new ExtentReports(); 
		htmlReporter.config().setAutoCreateRelativePathMedia(true);
		htmlReporter.config().setCSS("css-string");
		htmlReporter.config().setDocumentTitle("BOS Test Report");
		htmlReporter.config().setEncoding("utf-8");
		htmlReporter.config().setJS("js-string");
		htmlReporter.config().setProtocol(Protocol.HTTPS);
		htmlReporter.config().setReportName("BOS Test Report");
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
		report.attachReporter(htmlReporter);
		report.setSystemInfo("Application Name", "Bank Of Scotland");
		report.setSystemInfo("Simulator", "iPad Air (3rd generation)");
		report.setSystemInfo("Report Date", dateFormatForReport.format(date));
		//return fileName;

	}


	@AfterClass()
	public static void finishReport() {
		report.flush();
		driver.close();
		driver.quit();

	}
	
	
		
}
	